function Registra(){
	localStorage.setItem("Nombre",$("#usuario").val());
	console.log(localStorage.getItem("Nombre"));
}

function Cerrar(){
	localStorage.clear();
}

$(document).ready(function(){
	localStorage.getItem("Nombre");
	$('#bienvenido').html("<h1>Bienvenido "+localStorage.getItem("Nombre")+"</h1>");
});
